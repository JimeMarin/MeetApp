// Importa las funciones necesarias desde el SDK de Firebase
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// Configuración de Firebase para tu proyecto
const firebaseConfig = {
  apiKey: "AIzaSyD1pQojVUabbzMh3eaGGss0NI3DLPPka2g",
  authDomain: "meetapp-7cc2e.firebaseapp.com",
  projectId: "meetapp-7cc2e",
  storageBucket: "meetapp-7cc2e.appspot.com",
  messagingSenderId: "1087435563476",
  appId: "1:1087435563476:web:1ba2dd9e221b300dd37641"
};

// Inicializa la app de Firebase
const app = initializeApp(firebaseConfig);

// Exporta la autenticación de Firebase
export const auth = getAuth(app);
